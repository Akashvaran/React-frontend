import './App.css';
import Rouding from './my-project/mainRouder/Rouding';


function App() {
  return (
    <>
      <Rouding/>  
    </>
  );
}

export default App;
