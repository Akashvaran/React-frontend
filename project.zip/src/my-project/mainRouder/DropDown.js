import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Dropdown.css'

const DropdownComponent = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
 

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };
  const Closeoption=()=>{
    setIsDropdownOpen(false)
  }

  return (
    <div className="dropdown">
      <button className="dropbtn" onClick={toggleDropdown}>
        <img src='prifile.png' alt="Profile" className="profile-img" />
       <p>ourname</p>
      </button>
      {isDropdownOpen && (
        <div className="dropdown-content">
          <Link to={'/Profile'} onClick={Closeoption}>view profile</Link>
          <Link onClick={Closeoption}>Logout</Link>
         
          
        </div>
      )}
    </div>
  );
};

export default DropdownComponent;
