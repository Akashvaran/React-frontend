import React from 'react';
import './Roudeing.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import {Home} from '../condentfiles/Home.js'
import { About } from '../condentfiles/About';
import { Service } from '../condentfiles/Service';
import { Conduct } from '../condentfiles/Conduct';
import Navbar from './Navbar.js';
import { RegistrationForm } from '../fromvalitation/Register.js';
import LoginForm from '../fromvalitation/Login.js';
import { Profile } from '../fromvalitation/Profile.js';
import { Support } from '../condentfiles/Support.js';
import { Siderbar } from './SiderBar.js';
const Rouding = () => {
  return (
    <div className='main-content'>
      <BrowserRouter>
        <Navbar />
        <div className='navbar-components'>

          <Siderbar />
          <div className='Routes-component'>
          <Routes>
            
            <Route path='/' element={<Home />} />
            <Route path='/About' element={<About />} />
            <Route path='/Service' element={<Service />} />
            <Route path='/Conduct' element={<Conduct />} />

            <Route path='/singup' element={<RegistrationForm />} />

            <Route path='/login' element={<LoginForm />} />
            <Route path='/Profile' element={<Profile />} />
            <Route path='/home' element={<Home />} />
            <Route path="/" element={<Home />} />
            <Route path="/services" element={<About />} />
            <Route path="/contact" element={<Conduct />} />
            <Route path="/support" element={<Service />} />
            <Route path="/support" element={<Support />} />
            
          </Routes>
          </div>
        </div>
      </BrowserRouter>
    </div>

  );
};

export default Rouding;
