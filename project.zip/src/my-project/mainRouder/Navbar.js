import React, { useState } from 'react';
import './Navebar.css';
import { FaSearch } from 'react-icons/fa';
import { IoMdMenu, IoMdClose } from 'react-icons/io';
import { Link, useLocation } from 'react-router-dom';
import DropdownComponent from './DropDown';
import { RegistrationForm } from '../fromvalitation/Register';

const Navbar = () => {
  const [isActive, setIsActive] = useState(false);
  const [isSignUpVisible, setIsSignUpVisible] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsActive(!isActive);
  };

  const closeMenu = () => {
    setIsActive(false);
  };

  const toggleSignUpForm = () => {
    setIsSignUpVisible(!isSignUpVisible);
  };

  const handleCloseForm = () => {
    setIsSignUpVisible(false);
  };


  React.useEffect(() => {
    setIsSignUpVisible(false);
  }, [location.pathname]); 

  return (
    <div className='navbar'>
      <header>
        <div className='logo'>
          <h2>Project</h2>
        </div>
        <div className='search-box'>
          <form action='#'>
            <input type='text' className='search-bar' placeholder='Search' />
            <button type='submit' className='search-icon'><FaSearch /></button>
          </form>
        </div>
        <ul className={isActive ? 'active' : ''}>
          <li><Link to={'/'} onClick={closeMenu}>Home</Link></li>
          <li><Link to={'/About'} onClick={closeMenu}>About</Link></li>
          <li><Link to={'/Service'} onClick={closeMenu}>Service</Link></li>
          <li><Link to={'/Conduct'} onClick={closeMenu}>Conduct</Link></li>
        </ul>
        <div className='verification' onClick={toggleSignUpForm}>
          <h3 style={{ position: 'relative' }}>Signup</h3>
        </div>
        {isSignUpVisible && (
          <div className='SignUpBoxShow'>
            <div style={{ position: 'relative' }}>
              <span className='close-icon' onClick={handleCloseForm}><IoMdClose /></span>
              <RegistrationForm />
            </div>
          </div>
        )}
        <div className='menu' onClick={toggleMenu}>
          <IoMdMenu />
        </div>
        <div>
          <DropdownComponent />
        </div>
      </header>
    </div>
  );
};

export default Navbar;




