import React from 'react'

export const Profile = () => {
  return (
    <>
        <div>
            <div className='Profile-update'>
               {/* <img src='prifile.png' alt='' /> */}
               <h3>Add image</h3>
               <h3>Remove image</h3>

            </div>
          <div className='UserDatas'>
            <h4> Name</h4>
            <h4> Email</h4>
            <h4> phone no</h4>
            <h4> Password</h4>
          </div>


        </div>
    
    
    </>
  )
}
