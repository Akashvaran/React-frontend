import React, { useState } from 'react';
import './Login.css';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { IoMdClose } from "react-icons/io";
import { IoMdEye } from "react-icons/io";
import { IoIosEyeOff } from "react-icons/io";

const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isVisible, setIsVisible] = useState(true); // Initially visible
  const navigate = useNavigate();
  const [showpassworde, setShowPassworde]=useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8000/auth/login', { email, password });
      const { data } = response;
      
      if (data.msg === "password_incorrect") {
        alert("Incorrect password. Please check your password.");
      } else if (data.msg === "please_signup") {
        alert("You don't have an account. Please sign up.");
      } else if (data.msg === "login_success") {
        alert("Login successful");
        navigate('/home'); 
      }
    } catch (error) {
      console.error("Error occurred during login:", error);
      alert("An error occurred during login. Please try again.");
    }
  };

  const handleCloseForm = () => {
    setIsVisible(false); // Hide the form
  };

  // const handleShowForm = () => {
  //   setIsVisible(true); // Show the form
  // };

  return (
    <>
      {isVisible && ( // Render only if isVisible is true
        <div className="LoginForm">
          <span className='Closemenu' onClick={handleCloseForm}><IoMdClose /></span>
          <h2>Login</h2>
          <form onSubmit={handleSubmit}>
            <div className="InputContainer">
              <label htmlFor="email">Email</label>
              <input
                className='inputs'
                type="email"
                id="email"
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email"
                autoComplete="off"
              />
            </div>
            <div className="InputContainer">
              <label htmlFor="password">Password</label>
              <div className='passwordinput'>
              <input
                className='inputs'
                type={showpassworde? "text":"password"}
                id="password"
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                autoComplete="off"
              />
              <span onClick={()=>setShowPassworde((preve)=>(!preve))}>
                {
                  showpassworde ?(
                    < IoMdEye/>
                  ):(
                    <IoIosEyeOff />
                  )
                }
              </span>
              </div>
            </div>
            <div className="ButtonContainer">
              <button type="submit">Login</button>
            </div>
          </form>
          <div>
            Don't have an account? <Link to="/signUp">Click here to sign up</Link>
          </div>
        </div>
      )}
    </>
  );
};

export default LoginForm;






