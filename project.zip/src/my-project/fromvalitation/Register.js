import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { IoMdEye, IoIosEyeOff } from 'react-icons/io';

import 'react-toastify/dist/ReactToastify.css';
import './Register.css';

const RegistrationForm = () => {
  const [Name, setName] = useState('');
  const [Email, setEmail] = useState('');
  const [Mobile, setMobile] = useState('');
  const [Password, setPassword] = useState('');
  const [isChecked, setIsChecked] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [submitStatus, setSubmitStatus] = useState(null);
  const [showPassword, setShowPassword] = useState(false);

  const navigate = useNavigate();

  // toast.configure();

  const handleSubmit = (e) => {
    e.preventDefault();
    const errors = {};

    
    // Validate Name
    if (!Name.trim()) {
      errors.name = 'Name is required';
    } else if (!/^[a-zA-ZÀ-ÿ' .]+$/.test(Name)) {
      errors.name = 'Invalid name format';
    }
    // Validate Email
    if (!Email.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[a-z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(Email)) {
      errors.email = 'Invalid email format';
    }
    // Validate Mobile
    if (!Mobile.trim()) {
      errors.mobile = 'Mobile number is required';
    } else if (!/^\+?[0-9\-() ]+$/.test(Mobile)) {
      errors.mobile = 'Invalid mobile number';
    }
    // Validate Password
    if (!Password.trim()) {
      errors.password = 'Password is required';
    } else if (!/^(?:[a-zA-Z]+|\d+|[a-zA-Z\d]+)$/.test(Password)) {
      errors.password = 'Password must be alphabetic, numeric, or alphanumeric without special characters';
    }
    // Validate Terms and Conditions checkbox
    if (!isChecked) {
      errors.terms = 'Please accept the Terms and Conditions';
    }
    setFormErrors(errors);

    if (Object.keys(errors).length === 0) {
      axios
        .post('http://localhost:8000/auth/signup', { Name, Email, Mobile, Password })
        .then((res) => {
          if (res.data.msg === 'data_is_added') {
            setSubmitStatus('success');
            setName('');
            setEmail('');
            setMobile('');
            setPassword('');
            setIsChecked(false);
            navigate('/home');
          } else if (res.data.msg === 'exist') {
            setSubmitStatus('error');
          }
        })
        .catch((error) => {
          console.error('Error occurred during signup:', error);
          setSubmitStatus('error');
          
        });
    }
  };

  const handleCheckboxChange = (e) => {
    setIsChecked(e.target.checked);
  };
 

  return (
    <div className="Formvalidate">
      <form onSubmit={handleSubmit}>
        {submitStatus === 'error' && (
          <p className="submission-error" style={{ color: 'red' }}>
            An error occurred. Please try again.
          </p>
        )}
        {submitStatus === 'success' && (
          <p className="submission-success" style={{ color: 'green' }}>
            Signed up successfully
          </p>
        )}
        <div className="Userinput">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            name="name"
            id="name"
            placeholder="Enter name"
            value={Name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="off"
          />
          {formErrors.name && <p className="error" style={{color:"red"}}>{formErrors.name}</p>}
        </div>
        <div className="Userinput">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            name="email"
            id="email"
            placeholder="Enter email"
            value={Email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="off"
          />
          {formErrors.email && <p className="error" style={{color:"red"}}>{formErrors.email}</p>}
        </div>
        <div className="Userinput">
          <label htmlFor="mobile">Mobile</label>
          <input
            type="text"
            name="mobile"
            id="mobile"
            placeholder="Enter mobile number"
            value={Mobile}
            onChange={(e) => setMobile(e.target.value)}
            autoComplete="off"
          />
          {formErrors.mobile && <p className="error" style={{color:"red"}}>{formErrors.mobile}</p>}
        </div>
        <div className="Userinput">
          <label htmlFor="password">Password</label>
          <div className="password-input">
            <input
              type={showPassword ? 'text' : 'password'}
              name="password"
              id="password"
              placeholder="Enter password"
              value={Password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="off"
            />
            <span onClick={() => setShowPassword((prev) => !prev)}>
              {showPassword ? <IoMdEye /> : <IoIosEyeOff />}
            </span>
          </div>
          {formErrors.password && <p className="error" style={{color:"red"}}>{formErrors.password}</p>}
        </div>
        <div className="Checkbox">
          <input
            type="checkbox"
            id="terms"
            checked={isChecked}
            onChange={handleCheckboxChange}
          />
          <label htmlFor="terms">Accept Terms and Conditions</label>
        </div>
        {formErrors.terms && <p className="error" style={{color:"red"}}>{formErrors.terms}</p>}
        <div className="Button">
          <button type="submit">Register</button>
        </div>
        <div className="LoginRoute">
          Already have an account? <Link to="/login">Click here to login</Link>
        </div>
      </form>
    </div>
  );
};

export { RegistrationForm };




