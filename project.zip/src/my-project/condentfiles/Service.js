import React from 'react'

export const Service = () => {
  return (
    <div>Service</div>
  )
}
