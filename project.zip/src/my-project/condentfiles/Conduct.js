import React from 'react'

export const Conduct = () => {
  return (
    <div>Conduct</div>
  )
}
