import React from 'react'

export const Support = () => {
  return (
    <div>Support</div>
  )
}

